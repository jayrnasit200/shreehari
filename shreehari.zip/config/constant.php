<?php
    return [

        'product_div'=>'uploads/product',
        

        

    ];
